# Complete the GitHub upload and deploy

The text source files have already been committed to the repository. The ZIP supplied with this project contains the remaining binary model files and the labelled test CSV.

## Upload the remaining files
1. Download and extract the project ZIP.
2. Open the repository on GitHub and choose **Add file → Upload files**.
3. Open the extracted project folder and select the five `.pkl` files inside `models/` and `test_data.csv`. Keep the five model files inside a folder named `models`.
4. Commit the upload to the `main` branch.

## Deploy on Streamlit Community Cloud
1. Sign in at https://share.streamlit.io/ using the GitHub account that owns this repository.
2. Choose **Create app**, select repository `2026aj05404-dot/ML_Assignment`, branch `main`, and main file `app.py`.
3. Deploy. Wait for the build to finish and test the app using `test_data.csv`.
4. Copy the public app URL into the assignment PDF and README.

Run `python train_models.py` locally or in BITS Virtual Lab to regenerate the saved models and metrics. Capture your own genuine BITS Virtual Lab screenshot for submission.
